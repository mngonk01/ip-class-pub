from pyjokes import pyjokes
from flask import Flask, request, render_template, redirect, url_for

app = Flask(__name__)

@app.route('/', methods=["GET", "POST"])
def index():
    
    return render_template('index.html')


@app.route("/joke", methods=['GET','POST'])
def jokes():
    if request.method == 'POST':
        category = request.form.get("category")
        language = request.form.get("language")
        try:
            joke = pyjokes.get_joke(language=language, category=category)
        except Exception:
            return render_template('jokes.html', error="No Joke Available for the selected option")
        return render_template('jokes.html', joke=joke)

if __name__ == "__main__":
    app.run(debug=True)